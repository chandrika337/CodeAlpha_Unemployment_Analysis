import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

# ============================================================
# TASK 2: UNEMPLOYMENT ANALYSIS WITH PYTHON
# CodeAlpha Internship
# ============================================================

# -----------------------------
# 1. Load Dataset
# -----------------------------

file_path = "Unemployment in India.csv"

if not os.path.exists(file_path):
    print("ERROR: Dataset file not found!")
    print("Make sure 'Unemployment in India.csv' is in the same folder as this Python file.")
    exit()

df = pd.read_csv(file_path)

print("=" * 60)
print("UNEMPLOYMENT ANALYSIS")
print("=" * 60)

print("\nOriginal Dataset Shape:")
print(df.shape)

print("\nFirst 5 Rows:")
print(df.head())


# -----------------------------
# 2. Clean Column Names
# -----------------------------

df.columns = df.columns.str.strip()

print("\nColumn Names:")
print(df.columns.tolist())


# -----------------------------
# 3. Remove Extra Spaces
# -----------------------------

for column in df.select_dtypes(include="object").columns:
    df[column] = df[column].str.strip()


# -----------------------------
# 4. Convert Date Column
# -----------------------------

df["Date"] = pd.to_datetime(
    df["Date"],
    dayfirst=True,
    errors="coerce"
)

# Remove rows where date conversion failed
df = df.dropna(subset=["Date"])


# -----------------------------
# 5. Handle Missing Values
# -----------------------------

print("\nMissing Values Before Cleaning:")
print(df.isnull().sum())

numeric_columns = [
    "Estimated Unemployment Rate (%)",
    "Estimated Employed",
    "Estimated Labour Participation Rate (%)"
]

for column in numeric_columns:
    df[column] = pd.to_numeric(df[column], errors="coerce")

# Fill missing numerical values with median
for column in numeric_columns:
    df[column] = df[column].fillna(df[column].median())

print("\nMissing Values After Cleaning:")
print(df.isnull().sum())


# -----------------------------
# 6. Remove Duplicate Rows
# -----------------------------

duplicates = df.duplicated().sum()

print("\nDuplicate Rows:", duplicates)

df = df.drop_duplicates()

print("Shape After Cleaning:", df.shape)


# -----------------------------
# 7. Basic Statistical Analysis
# -----------------------------

unemployment_column = "Estimated Unemployment Rate (%)"

print("\n" + "=" * 60)
print("STATISTICAL SUMMARY")
print("=" * 60)

print(df[[
    unemployment_column,
    "Estimated Employed",
    "Estimated Labour Participation Rate (%)"
]].describe())


# -----------------------------
# 8. Average Unemployment Rate
# -----------------------------

average_unemployment = df[unemployment_column].mean()

print("\nAverage Unemployment Rate:")
print(f"{average_unemployment:.2f}%")


# -----------------------------
# 9. Highest Unemployment Rate
# -----------------------------

highest_index = df[unemployment_column].idxmax()
highest_record = df.loc[highest_index]

print("\n" + "=" * 60)
print("HIGHEST UNEMPLOYMENT RATE")
print("=" * 60)

print("Region:", highest_record["Region"])
print("Date:", highest_record["Date"].strftime("%d-%m-%Y"))
print("Area:", highest_record["Area"])
print(
    "Unemployment Rate:",
    f"{highest_record[unemployment_column]:.2f}%"
)


# -----------------------------
# 10. Lowest Unemployment Rate
# -----------------------------

lowest_index = df[unemployment_column].idxmin()
lowest_record = df.loc[lowest_index]

print("\n" + "=" * 60)
print("LOWEST UNEMPLOYMENT RATE")
print("=" * 60)

print("Region:", lowest_record["Region"])
print("Date:", lowest_record["Date"].strftime("%d-%m-%Y"))
print("Area:", lowest_record["Area"])
print(
    "Unemployment Rate:",
    f"{lowest_record[unemployment_column]:.2f}%"
)


# -----------------------------
# 11. State/Region-wise Analysis
# -----------------------------

region_average = (
    df.groupby("Region")[unemployment_column]
    .mean()
    .sort_values(ascending=False)
)

print("\n" + "=" * 60)
print("AVERAGE UNEMPLOYMENT RATE BY REGION")
print("=" * 60)

print(region_average)


# -----------------------------
# 12. Area-wise Analysis
# -----------------------------

area_average = (
    df.groupby("Area")[unemployment_column]
    .mean()
    .sort_values(ascending=False)
)

print("\n" + "=" * 60)
print("AVERAGE UNEMPLOYMENT RATE BY AREA")
print("=" * 60)

print(area_average)


# -----------------------------
# 13. Monthly Average
# -----------------------------

df["Month"] = df["Date"].dt.month
df["Month_Name"] = df["Date"].dt.strftime("%B")
df["Year"] = df["Date"].dt.year

monthly_average = (
    df.groupby("Month")[unemployment_column]
    .mean()
)

print("\n" + "=" * 60)
print("MONTHLY AVERAGE UNEMPLOYMENT")
print("=" * 60)

print(monthly_average)


# -----------------------------
# 14. Year-wise Analysis
# -----------------------------

year_average = (
    df.groupby("Year")[unemployment_column]
    .mean()
)

print("\n" + "=" * 60)
print("YEAR-WISE AVERAGE UNEMPLOYMENT")
print("=" * 60)

print(year_average)


# -----------------------------
# 15. COVID-19 Analysis
# -----------------------------
# Dataset covers 2019 and 2020.
# We use March 2020 as the beginning
# of the COVID-19 period for comparison.

pre_covid = df[df["Date"] < "2020-03-01"]

covid_period = df[
    (df["Date"] >= "2020-03-01") &
    (df["Date"] <= "2020-11-30")
]

pre_covid_average = pre_covid[unemployment_column].mean()
covid_average = covid_period[unemployment_column].mean()

print("\n" + "=" * 60)
print("COVID-19 IMPACT ANALYSIS")
print("=" * 60)

print(
    f"Average unemployment before March 2020: "
    f"{pre_covid_average:.2f}%"
)

print(
    f"Average unemployment during March-November 2020: "
    f"{covid_average:.2f}%"
)

change = covid_average - pre_covid_average

print(
    f"Change in average unemployment: "
    f"{change:.2f} percentage points"
)


# -----------------------------
# 16. Highest COVID-19 Unemployment
# -----------------------------

if not covid_period.empty:

    covid_highest_index = covid_period[unemployment_column].idxmax()
    covid_highest = covid_period.loc[covid_highest_index]

    print("\nHighest unemployment during COVID period:")

    print("Region:", covid_highest["Region"])
    print("Date:", covid_highest["Date"].strftime("%d-%m-%Y"))
    print("Area:", covid_highest["Area"])
    print(
        "Rate:",
        f"{covid_highest[unemployment_column]:.2f}%"
    )


# ============================================================
# VISUALIZATION
# ============================================================

sns.set_theme(style="whitegrid")

# Create output folder
os.makedirs("visualizations", exist_ok=True)


# -----------------------------
# Graph 1: Overall Trend
# -----------------------------

monthly_trend = (
    df.groupby("Date")[unemployment_column]
    .mean()
    .reset_index()
)

plt.figure(figsize=(12, 6))

plt.plot(
    monthly_trend["Date"],
    monthly_trend[unemployment_column],
    marker="o"
)

plt.title("Unemployment Rate in India Over Time")
plt.xlabel("Date")
plt.ylabel("Unemployment Rate (%)")

plt.xticks(rotation=45)

plt.tight_layout()

plt.savefig(
    "visualizations/unemployment_trend.png",
    dpi=300
)

plt.show()


# -----------------------------
# Graph 2: COVID-19 Comparison
# -----------------------------

comparison_data = pd.DataFrame({
    "Period": [
        "Before COVID-19",
        "COVID-19 Period"
    ],
    "Unemployment Rate": [
        pre_covid_average,
        covid_average
    ]
})

plt.figure(figsize=(8, 6))

sns.barplot(
    data=comparison_data,
    x="Period",
    y="Unemployment Rate"
)

plt.title("Unemployment Rate Before and During COVID-19")
plt.xlabel("Period")
plt.ylabel("Average Unemployment Rate (%)")

plt.tight_layout()

plt.savefig(
    "visualizations/covid_comparison.png",
    dpi=300
)

plt.show()


# -----------------------------
# Graph 3: Region-wise Analysis
# -----------------------------

plt.figure(figsize=(12, 8))

region_plot = region_average.sort_values()

sns.barplot(
    x=region_plot.values,
    y=region_plot.index
)

plt.title("Average Unemployment Rate by Region")
plt.xlabel("Average Unemployment Rate (%)")
plt.ylabel("Region")

plt.tight_layout()

plt.savefig(
    "visualizations/region_unemployment.png",
    dpi=300
)

plt.show()


# -----------------------------
# Graph 4: Rural vs Urban
# -----------------------------

plt.figure(figsize=(8, 6))

sns.barplot(
    data=df,
    x="Area",
    y=unemployment_column
)

plt.title("Unemployment Rate: Rural vs Urban")
plt.xlabel("Area")
plt.ylabel("Unemployment Rate (%)")

plt.tight_layout()

plt.savefig(
    "visualizations/rural_vs_urban.png",
    dpi=300
)

plt.show()


# -----------------------------
# Graph 5: Monthly Trend
# -----------------------------

month_order = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
]

month_data = (
    df.groupby("Month_Name")[unemployment_column]
    .mean()
    .reindex(month_order)
    .dropna()
)

plt.figure(figsize=(12, 6))

sns.barplot(
    x=month_data.index,
    y=month_data.values
)

plt.title("Average Unemployment Rate by Month")
plt.xlabel("Month")
plt.ylabel("Average Unemployment Rate (%)")

plt.xticks(rotation=45)

plt.tight_layout()

plt.savefig(
    "visualizations/monthly_unemployment.png",
    dpi=300
)

plt.show()


# -----------------------------
# Graph 6: Employment Trend
# -----------------------------

employment_trend = (
    df.groupby("Date")["Estimated Employed"]
    .mean()
    .reset_index()
)

plt.figure(figsize=(12, 6))

plt.plot(
    employment_trend["Date"],
    employment_trend["Estimated Employed"],
    marker="o"
)

plt.title("Estimated Employment Trend in India")
plt.xlabel("Date")
plt.ylabel("Estimated Employed")

plt.xticks(rotation=45)

plt.tight_layout()

plt.savefig(
    "visualizations/employment_trend.png",
    dpi=300
)

plt.show()


# -----------------------------
# Final Summary
# -----------------------------

print("\n" + "=" * 60)
print("PROJECT SUMMARY")
print("=" * 60)

print(f"Total records analyzed: {len(df)}")
print(f"Average unemployment rate: {average_unemployment:.2f}%")
print(f"Before COVID-19 average: {pre_covid_average:.2f}%")
print(f"COVID-19 period average: {covid_average:.2f}%")
print(f"Change during COVID-19: {change:.2f} percentage points")

print("\nVisualizations saved inside:")
print("visualizations/")

print("\nAnalysis completed successfully!")

